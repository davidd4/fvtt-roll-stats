import Settings from "./Settings.js";
import constants from "./constants.js";
import SadnessChan from "./SadnessChan.js";
class RollStats {
    constructor() {
    }
    static getInstance() {
        if (!RollStats._instance)
            RollStats._instance = new RollStats();
        return RollStats._instance;
    }
    resetCompleteStats() {
        game.users.forEach(user => {
            this._setRollHistory(user, {});
        });
    }
    resetSessionStats() {
        game.users.forEach(user => {
            var _a;
            let rollHistory = (_a = this._getRollHistory(user)) !== null && _a !== void 0 ? _a : {};
            if (rollHistory["session"] != null) {
                rollHistory["session"] = {};
                this._setRollHistory(user, rollHistory);
            }
        });
    }
    resetViaSadness() {
        let sadnessRollHistory = SadnessChan.getRollHistory();
        game.users.forEach(user => {
            let rollHistory = {};
            let userRolls = SadnessChan.getUserRollHistory(sadnessRollHistory, user);
            if (userRolls != null && userRolls.length) {
                let [dummy, ...rolls] = userRolls;
                let dieType = this._getDieType(rolls.length);
                if (dieType != null) {
                    let diceMap = rollHistory["all-time"] = rollHistory["session"] = {};
                    diceMap[dieType] = rolls;
                }
            }
            this._setRollHistory(user, rollHistory);
        });
    }
    getUserData(user, dieType) {
        var _a, _b, _c, _d;
        const rollHistory = this._getRollHistory(user);
        if (rollHistory == null)
            return null;
        const allTimeMap = (_a = rollHistory["all-time"]) !== null && _a !== void 0 ? _a : {};
        const sessionMap = (_b = rollHistory["session"]) !== null && _b !== void 0 ? _b : {};
        const size = this._getDieSize(dieType);
        const emptyArray = this._getZeroArray(size);
        return {
            allTime: this._createUserRollStats((_c = allTimeMap[dieType]) !== null && _c !== void 0 ? _c : emptyArray, dieType),
            session: this._createUserRollStats((_d = sessionMap[dieType]) !== null && _d !== void 0 ? _d : emptyArray, dieType),
        };
    }
    addRolls(user, size, rolls) {
        var _a, _b, _c, _d, _e;
        let dieType = this._getDieType(size);
        if (dieType == null)
            return;
        let rollHistory = (_a = this._getRollHistory(user)) !== null && _a !== void 0 ? _a : {};
        const allTimeMap = (_b = rollHistory["all-time"]) !== null && _b !== void 0 ? _b : {};
        const sessionMap = (_c = rollHistory["session"]) !== null && _c !== void 0 ? _c : {};
        allTimeMap[dieType] = (_d = allTimeMap[dieType]) !== null && _d !== void 0 ? _d : this._getZeroArray(size);
        sessionMap[dieType] = (_e = sessionMap[dieType]) !== null && _e !== void 0 ? _e : this._getZeroArray(size);
        for (let i = 0; i < rolls.length; i++) {
            allTimeMap[dieType][rolls[i] - 1] = allTimeMap[dieType][rolls[i] - 1] + 1;
            sessionMap[dieType][rolls[i] - 1] = sessionMap[dieType][rolls[i] - 1] + 1;
        }
        rollHistory["all-time"] = allTimeMap;
        rollHistory["session"] = sessionMap;
        this._setRollHistory(user, rollHistory);
    }
    _createUserRollStats(rolls, dieType) {
        const calcStats = this._getCalcStats(rolls);
        return {
            dieType: dieType,
            rolls: rolls,
            numberOfRolls: calcStats.numberOfRolls,
            average: calcStats.average,
            highest: calcStats.highest,
            percentages: calcStats.percentages
        };
    }
    _getCalcStats(rolls) {
        let rollsTotal = 0;
        let numberOfRolls = 0;
        let highest = 0;
        for (let i = 0; i < rolls.length; i++) {
            rollsTotal += (i + 1) * rolls[i];
            numberOfRolls += rolls[i];
            highest = Math.max(rolls[i], highest);
        }
        let average = this._roundUp(rollsTotal / numberOfRolls) || 0;
        let percentages = this._getZeroArray(rolls.length);
        for (let i = 0; i < rolls.length; i++) {
            let percentage = numberOfRolls != 0 ? this._roundUp((rolls[i] / numberOfRolls) * 100) : 0;
            percentages[i] = percentage;
        }
        return {
            numberOfRolls: numberOfRolls,
            average: average,
            highest: highest,
            percentages: percentages
        };
    }
    _roundUp(nr) {
        return Math.round((nr + Number.EPSILON) * 10) / 10;
    }
    _getRollHistory(user) {
        const rollHistory = Settings.getSetting(Settings.SETTING_KEYS.ROLL_HISTORY);
        return rollHistory[user.id];
    }
    _setRollHistory(user, userRollHistory) {
        let rollHistory = Settings.getSetting(Settings.SETTING_KEYS.ROLL_HISTORY);
        rollHistory[user.id] = userRollHistory;
        Settings.setSetting(Settings.SETTING_KEYS.ROLL_HISTORY, rollHistory);
    }
    _getDieType(size) {
        let dieType = `d${size}`;
        return constants.dieTypes.includes(dieType) ? dieType : null;
    }
    _getDieSize(dieType) {
        var match = dieType.match(/d(\d+)/i);
        return match != null ? match[1] : 0;
    }
    _getZeroArray(length) {
        const zeroArray = new Array();
        for (let i = 0; i < length; i++)
            zeroArray.push(0);
        return zeroArray;
    }
}
export default RollStats.getInstance();
