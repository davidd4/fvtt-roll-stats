import Settings from "./Settings.js";
import constants from "./constants.js";
import SadnessChan from "./SadnessChan.js";
class RollStats {
    constructor() {
    }
    static getInstance() {
        if (!RollStats._instance)
            RollStats._instance = new RollStats();
        return RollStats._instance;
    }
    getChatCommand() {
        return Settings.getSetting(Settings.SETTING_KEYS.STATS_CMD);
    }
    resetCompleteStats() {
        game.users.forEach(user => {
            this._setRollHistory(user, {});
        });
    }
    resetSessionStats() {
        game.users.forEach(user => {
            let rollHistory = this._getRollHistory(user);
            if (rollHistory["session"] != null) {
                rollHistory["session"] = {};
                this._setRollHistory(user, rollHistory);
            }
        });
    }
    resetViaSadness() {
        let sadnessRollHistory = SadnessChan.getRollHistory();
        game.users.forEach(user => {
            let rollHistory = {};
            let userRolls = SadnessChan.getUserRollHistory(sadnessRollHistory, user);
            if (userRolls != null && userRolls.length) {
                let [dummy, ...rolls] = userRolls;
                let dieType = this._getDieType(rolls.length);
                let diceMap = rollHistory["all-time"] = rollHistory["session"] = {};
                diceMap[dieType] = userRolls;
            }
            this._setRollHistory(user, rollHistory);
        });
    }
    _getRollHistory(user) {
        var _a;
        let rollHistory = (_a = user.getFlag(constants.moduleName, "rollHistory")) !== null && _a !== void 0 ? _a : {};
    }
    _setRollHistory(user, rollHistory) {
        user.setFlag(constants.moduleName, "rollHistory", rollHistory);
    }
    _getDieType(size) {
        return `d${size}`;
    }
}
export default RollStats.getInstance();
