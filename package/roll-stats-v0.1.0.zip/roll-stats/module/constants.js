export default {
    moduleName: "roll-stats",
    sadnessModuleName: 'sadness-chan'
};
