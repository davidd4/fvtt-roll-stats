import constants from "./constants.js";
class Settings {
    constructor() {
        this.SETTING_KEYS = {
            STATS_CMD: 'statsCommand',
        };
        this.SETTING_DEFAULTS = {
            STATS_CMD: `!rollstats`,
        };
    }
    static getInstance() {
        if (!Settings._instance)
            Settings._instance = new Settings();
        return Settings._instance;
    }
    registerSettings() {
        this.SETTINGS.forEach((setting) => {
            this._registerSetting(setting.key, setting.data);
        });
    }
    _registerSetting(key, data) {
        game.settings.register(constants.moduleName, key, data);
    }
    getSadnessSetting(key) {
        return this._getSetting(constants.sadnessModuleName, key);
    }
    getSetting(key) {
        return this._getSetting(constants.moduleName, key);
    }
    _getSetting(module, key) {
        return game.settings.get(module, key);
    }
}
export default Settings.getInstance();
