class Templates {
    constructor() {
        this.templatePaths = [
        // Add paths to "modules/fvvt-roll-stats/templates"
        ];
        this.preloadTemplates = async function () {
            return loadTemplates(this.templatePaths);
        };
    }
    static getInstance() {
        if (!Templates._instance)
            Templates._instance = new Templates();
        return Templates._instance;
    }
}
export default Templates.getInstance();
