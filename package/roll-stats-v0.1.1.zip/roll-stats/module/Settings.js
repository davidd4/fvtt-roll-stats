import constants from "./constants.js";
class Settings {
    constructor() {
        this.SETTING_KEYS = {
            STATS_CMD: 'statsCommand',
            ROLL_HISTORY: 'rollHistory',
        };
        this.SETTING_DEFAULTS = {
            STATS_CMD: `!rollstats`,
        };
        this.SETTINGS = [
            {
                key: "statsCommand",
                data: {
                    name: "Stats command:",
                    hint: "Chat command",
                    type: String,
                    default: "!rollstats",
                    scope: "world",
                    config: true,
                    restricted: true,
                }
            },
            {
                key: "rollHistory",
                data: {
                    type: Object,
                    default: {},
                    scope: "world",
                    config: false,
                    restricted: false,
                },
            }
        ];
    }
    static getInstance() {
        if (!Settings._instance)
            Settings._instance = new Settings();
        return Settings._instance;
    }
    registerSettings() {
        this.SETTINGS.forEach((setting) => {
            this._registerSetting(setting.key, setting.data);
        });
    }
    _registerSetting(key, data) {
        game.settings.register(constants.moduleName, key, data);
    }
    getSadnessSetting(key) {
        return this._getSetting(constants.sadnessModuleName, key);
    }
    getSetting(key) {
        return this._getSetting(constants.moduleName, key);
    }
    async setSetting(key, value) {
        await this._setSetting(constants.moduleName, key, value);
    }
    _getSetting(module, key) {
        return game.settings.get(module, key);
    }
    async _setSetting(module, key, value) {
        await game.settings.set(module, key, value);
    }
}
export default Settings.getInstance();
