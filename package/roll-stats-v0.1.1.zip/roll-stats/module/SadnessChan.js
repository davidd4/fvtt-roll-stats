import Settings from "./Settings.js";
class SadnessChan {
    constructor() {
        this.SETTING_KEYS = {
            COUNTER: 'counter',
        };
    }
    static getInstance() {
        if (!SadnessChan._instance)
            SadnessChan._instance = new SadnessChan();
        return SadnessChan._instance;
    }
    getRollHistory() {
        var setting = Settings.getSadnessSetting(this.SETTING_KEYS.COUNTER);
        try {
            return JSON.parse(setting);
        }
        catch (error) {
            return {};
        }
    }
    getUserRollHistory(rollHistory, user) {
        let userData = rollHistory[user.id];
        return userData === null || userData === void 0 ? void 0 : userData.rolls;
    }
}
export default SadnessChan.getInstance();
