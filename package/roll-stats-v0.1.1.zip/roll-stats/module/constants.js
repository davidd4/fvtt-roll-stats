export default {
    moduleName: "roll-stats",
    sadnessModuleName: 'sadness-chan',
    dieTypes: ["d4", "d6", "d8", "d10", "d12", "d20", "d100"]
};
