import RollStats from "./RollStats.js";
var ChartType;
(function (ChartType) {
    ChartType[ChartType["Session"] = 1] = "Session";
    ChartType[ChartType["AllTime"] = 2] = "AllTime";
})(ChartType || (ChartType = {}));
class RollListener {
    constructor() {
    }
    static getInstance() {
        if (!RollListener._instance)
            RollListener._instance = new RollListener();
        return RollListener._instance;
    }
    async handleCreateChatMessage(chatMessage) {
        var _a;
        const userId = (_a = chatMessage === null || chatMessage === void 0 ? void 0 : chatMessage.user) === null || _a === void 0 ? void 0 : _a.id;
        if (!(userId && game.user.hasRole(4)))
            return;
        const user = game.users.find(x => x.id == userId);
        this._extractRoll(chatMessage === null || chatMessage === void 0 ? void 0 : chatMessage._roll, chatMessage, user);
    }
    _extractRoll(roll, chatMessage, user) {
        var _a, _b, _c;
        if (roll) {
            return this._extractSimpleRoll(roll, user);
        }
        if (game.data.version > '0.6.5') {
            const extractedURIEmbedded = this._extractUnparsedRollsFromEmbedded((_a = chatMessage === null || chatMessage === void 0 ? void 0 : chatMessage.data) === null || _a === void 0 ? void 0 : _a.content);
            if (extractedURIEmbedded && extractedURIEmbedded.length > 0) {
                return this._parseEmbeddedRolls(extractedURIEmbedded, user);
            }
        }
        if (this._isBR5eInstalled() && ((_b = chatMessage === null || chatMessage === void 0 ? void 0 : chatMessage.data) === null || _b === void 0 ? void 0 : _b.content)) {
            const extractedStringsFromBR5e = this._extractUnparsedRollsFromBR5e((_c = chatMessage === null || chatMessage === void 0 ? void 0 : chatMessage.data) === null || _c === void 0 ? void 0 : _c.content);
            if (extractedStringsFromBR5e && extractedStringsFromBR5e.length > 0) {
                return this._extractBR5eRolls(extractedStringsFromBR5e, user);
            }
        }
    }
    /* Simple rolls */
    async _extractSimpleRoll(roll, user) {
        const dice = roll.dice && roll.dice.length !== 0 ? roll.dice : roll._dice;
        if (!((dice === null || dice === void 0 ? void 0 : dice.length) > 0))
            return;
        for (const die of dice) {
            const results = die.results || die.rolls;
            const rolls = results.map(roll => roll.result || roll.roll);
            await RollStats.addRolls(user, die.faces, rolls);
        }
    }
    /* Embedded rolls */
    _extractUnparsedRollsFromEmbedded(message) {
        if (!message)
            return null;
        const regexRoll = /roll=\"(.*?)\"/g;
        return [...message.matchAll(regexRoll)];
    }
    async _parseEmbeddedRolls(matches, user) {
        if (!(matches && matches.length > 0))
            return;
        for (const element of matches) {
            try {
                const parsedEmbedded = JSON.parse(decodeURIComponent(element[1]));
                const dice = this._extractEmbeddedDice(parsedEmbedded, user);
                for (const die of dice) {
                    await RollStats.addRolls(user, die.faces, die.rolls);
                }
            }
            catch (error) {
            }
        }
    }
    _extractEmbeddedDice(messageJSON, user) {
        const terms = messageJSON.terms;
        if (!terms)
            return [];
        let result = [];
        return terms.forEach(term => {
            if ((term === null || term === void 0 ? void 0 : term.faces) != null) {
                result.push({
                    faces: term.faces,
                    rolls: term.results.map(element => element.result)
                });
            }
        });
        return result;
    }
    /* Better rolls 5e */
    _isBR5eInstalled() {
        return !!game.modules.get('betterrolls5e');
    }
    _extractUnparsedRollsFromBR5e(message) {
        const rollsRegExp = new RegExp(`<li.*roll die d(\\d+).*>([0-9]+)<\/li>`, 'g');
        return [...message.matchAll(rollsRegExp)];
    }
    async _extractBR5eRolls(rolls, user) {
        if (!((rolls === null || rolls === void 0 ? void 0 : rolls.length) > 0))
            return [];
        let dice = rolls.filter(x => (x[1] && x[2]))
            .reduce((rv, x) => {
            var _a;
            let die = (_a = rv[x[1]]) !== null && _a !== void 0 ? _a : {
                faces: parseInt(x[1]),
                rolls: []
            };
            die.rolls.push(parseInt(x[2]));
            rv[x[1]] = die;
            return rv;
        }, {});
        for (const die of Object.values(dice)) {
            await RollStats.addRolls(user, die["faces"], die["rolls"]);
        }
    }
}
export default RollListener.getInstance();
